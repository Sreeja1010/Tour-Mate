import React from 'react';
import { Compass, UtensilsCrossed, Car, Building2 } from 'lucide-react';

const categories = [
  {
    id: 'attractions',
    title: 'Tourist Attractions',
    icon: Compass,
    description: 'Discover amazing local attractions and landmarks',
    color: 'bg-purple-500'
  },
  {
    id: 'food',
    title: 'Local Cuisine',
    icon: UtensilsCrossed,
    description: 'Find and order from the best restaurants',
    color: 'bg-red-500'
  },
  {
    id: 'transport',
    title: 'Transportation',
    icon: Car,
    description: 'Book reliable transport services',
    color: 'bg-blue-500'
  },
  {
    id: 'hotels',
    title: 'Accommodations',
    icon: Building2,
    description: 'Find perfect places to stay',
    color: 'bg-green-500'
  }
];

export default function Categories() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">
          Everything You Need
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <div
              key={category.id}
              className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-6"
            >
              <div className={`${category.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
                <category.icon className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{category.title}</h3>
              <p className="text-gray-600">{category.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}