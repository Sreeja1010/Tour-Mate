import React from 'react';
import { Star, Navigation } from 'lucide-react';

const attractions = [
  {
    id: 1,
    name: 'Historical Museum',
    image: 'https://images.unsplash.com/photo-1582034986517-30d163aa1da9?auto=format&fit=crop&q=80',
    rating: 4.8,
    distance: '2.5 km',
    price: '$$'
  },
  {
    id: 2,
    name: 'Botanical Gardens',
    image: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&q=80',
    rating: 4.6,
    distance: '3.8 km',
    price: '$'
  },
  {
    id: 3,
    name: 'Art Gallery',
    image: 'https://images.unsplash.com/photo-1577083552431-6e5fd01988ec?auto=format&fit=crop&q=80',
    rating: 4.7,
    distance: '1.2 km',
    price: '$$'
  }
];

export default function Attractions() {
  return (
    <section id="attractions" className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">
          Popular Attractions
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {attractions.map((attraction) => (
            <div key={attraction.id} className="group">
              <div className="relative overflow-hidden rounded-xl">
                <img
                  src={attraction.image}
                  alt={attraction.name}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-0 p-4 text-white">
                  <h3 className="text-xl font-semibold mb-2">{attraction.name}</h3>
                  <div className="flex items-center space-x-4">
                    <span className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 mr-1" />
                      {attraction.rating}
                    </span>
                    <span className="flex items-center">
                      <Navigation className="h-4 w-4 mr-1" />
                      {attraction.distance}
                    </span>
                    <span>{attraction.price}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}