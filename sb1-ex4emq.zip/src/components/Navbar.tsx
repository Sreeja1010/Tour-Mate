import React from 'react';
import { Menu, Search, User } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="fixed top-0 w-full bg-white/80 backdrop-blur-md z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Menu className="h-6 w-6 text-gray-600 lg:hidden" />
            <span className="ml-4 text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-500 bg-clip-text text-transparent">
              Wanderlust
            </span>
          </div>
          
          <div className="hidden lg:flex items-center space-x-8">
            <a href="#attractions" className="text-gray-600 hover:text-gray-900">Attractions</a>
            <a href="#food" className="text-gray-600 hover:text-gray-900">Restaurants</a>
            <a href="#transport" className="text-gray-600 hover:text-gray-900">Transport</a>
            <a href="#hotels" className="text-gray-600 hover:text-gray-900">Hotels</a>
          </div>

          <div className="flex items-center space-x-4">
            <Search className="h-5 w-5 text-gray-600" />
            <User className="h-5 w-5 text-gray-600" />
          </div>
        </div>
      </div>
    </nav>
  );
}